// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC4oQaUP-wM0blQlIJlNLFK9wWjVvh--SI",
  authDomain: "shop-46782.firebaseapp.com",
  projectId: "shop-46782",
  storageBucket: "shop-46782.appspot.com",
  messagingSenderId: "711178743013",
  appId: "1:711178743013:web:b963df54eabeb3267e380c",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;
